simplefadeslideshow
===================

jQuery SimpleFadeSlideShow v.2.2.1
=======

Simple Fade SlideShow is a very simple and easy to use fade-image slideshow. Its structure is very flexible and you can use it for image and / or content transition.

Simple Fade SlideShow is lightweight and fast: Only ~7kb – minified ~3,8kb

Simple Fade SlideShow is highly customizable with CSS and it can either create the list and buttons automatically or you can create your own individual elements and Simple Fade SlideShow will only bind the relevant functions.

Copyright (c) 2016 Pascal Bajorat
Dual licensed under the MIT and Gnu GPL version 3 licenses.



## [Main Demo](http://www.simplefadeslideshow.com/)

* [Documentation](http://www.simplefadeslideshow.com/documentation/)
* [Latest demos](http://www.simplefadeslideshow.com/)
* [Download](http://www.simplefadeslideshow.com/download/)
* [Author](https://www.pascal-bajorat.com/)